from flask import Flask, render_template, url_for, request, redirect
from flask import Markup, request,session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import cryptocode

key='qwert'


app=Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///blog.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
app.config['SECRET_KEY']='LongAndRandomSecretKey'
db=SQLAlchemy(app)


class Article(db.Model):
    id=db.Column(db.Integer, primary_key=True)
    title=db.Column(db.String(100), nullable=False)
    intro=db.Column(db.String(300), nullable=False)
    text=db.Column(db.Text, nullable=False)
    date=db.Column(db.DateTime, default=datetime.utcnow)
    doctor=db.Column(db.Integer, nullable=False)

    def __repr__(self):
        return '<Article %r>' % self.id

class Doctors(db.Model):
    doctor_id=db.Column(db.Integer, primary_key=True)
    username=db.Column(db.Text, nullable=False)
    password=db.Column(db.Text, nullable=False)
    

    def __repr__(self):
        return '<Doctors %r>' % self.doctor_id


@app.route('/')
@app.route('/home')
def index():
    return render_template('index.html')

@app.route('/site')
def site():
    return render_template('site.html')

@app.route('/error')
def error():
    return render_template('error.html')

@app.route('/posts')
def posts():
    q=request.args.get('q')
    if q:
        articles=Article.query.filter(Article.title.contains(q)).order_by(Article.date.desc()).all()
    else:
        articles=Article.query.order_by(Article.date.desc()).all()
    return render_template('posts.html', articles=articles)
    


@app.route('/posts/<int:id>')
def post_detail(id):
    article=Article.query.get(id)
    return render_template('post_detail.html', article=article)


@app.route('/posts/<int:id>/del')
def post_delete(id):
    article=Article.query.get_or_404(id)
    try:
        db.session.delete(article)
        db.session.commit()
        return redirect('/posts')
    except:
        return 'При удалении статьи произошла ошибка'
    

@app.route('/posts/<int:id>/update', methods=['POST', 'GET'])
def post_update(id):
    article=Article.query.get(id)
    if request.method=='POST':
        article.title=request.form['title']
        article.intro=request.form['intro']
        article.text=request.form['text']


        try:
            db.session.commit()
            return redirect('/posts')
        except:
            return 'Ошибка при редактировании статьи'
    else:
        return render_template('post_update.html', article=article)



@app.route('/create-article', methods=['POST', 'GET'])
def create_article():
    if request.method=='POST':
        title=request.form['title']
        intro=request.form['intro']
        text=request.form['text']
        doctor=temp_doctor

        article=Article(title=title, intro=intro, text=text, doctor=doctor)

        try:
            db.session.add(article)
            db.session.commit()
            return redirect('/posts')
        except:
            return 'Ошибка при добавлении статьи'
    else:
        return render_template('create-article.html')


@app.route('/registration', methods=['POST', 'GET'])
def registration():
    if request.method=='POST':
        username=request.form['username']
        password=request.form['password']
    

        doctor=Doctors(username=username, password=cryptocode.encrypt(password, key))

        try:
            db.session.add(doctor)
            db.session.commit()
            return redirect('/site')
        except:
            return 'Ошибка при добавлении врача'
    else:
        return render_template('registration.html')


@app.route('/auth', methods=['POST', 'GET'])
def auth():
   
    if request.method=='POST':
        username_=request.form['username']
        password_=request.form['password']

        doctor=Doctors(username=username_, password=password_)
        doctors=Doctors.query.all()

        try:
            for i in doctors:
                if i.username==doctor.username and cryptocode.decrypt(i.password,key)==doctor.password:
                    global temp_doctor
                    temp_doctor=i.doctor_id
                    return redirect('/site')
                    break
            else:
                return redirect('/error')
        except:
            return redirect('/error')
    else:
        return render_template('auth.html')
            


if __name__=='__main__':
    app.run(debug=True)